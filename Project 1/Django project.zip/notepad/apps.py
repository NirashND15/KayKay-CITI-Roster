from django.apps import AppConfig


class NotepadConfig(AppConfig):
    name = 'notepad'
